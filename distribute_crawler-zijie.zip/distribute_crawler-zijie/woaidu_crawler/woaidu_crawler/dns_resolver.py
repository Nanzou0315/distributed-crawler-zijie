#!/usr/bin/env python
# -*- coding: utf-8 -*-

import dns.resolver
import redis
from urllib.parse import urlparse
import time
import json
from typing import Optional, Dict, List

class DNSCache:
    def __init__(self, redis_host: str = 'localhost', redis_port: int = 6379, redis_db: int = 0):
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, db=redis_db)
        self.cache_key_prefix = 'dns_cache:'
        self.expire_time = 3600  # 1小时过期

    def _get_cache_key(self, domain: str) -> str:
        return f"{self.cache_key_prefix}{domain}"

    def get(self, domain: str) -> Optional[List[str]]:
        """从缓存获取DNS解析结果"""
        cache_data = self.redis_client.get(self._get_cache_key(domain))
        if cache_data:
            return json.loads(cache_data)
        return None

    def set(self, domain: str, ips: List[str]):
        """设置DNS解析结果到缓存"""
        self.redis_client.setex(
            self._get_cache_key(domain),
            self.expire_time,
            json.dumps(ips)
        )

class DNSResolver:
    def __init__(self, redis_host: str = 'localhost', redis_port: int = 6379, redis_db: int = 0):
        self.resolver = dns.resolver.Resolver()
        self.resolver.timeout = 2
        self.resolver.lifetime = 4
        self.cache = DNSCache(redis_host, redis_port, redis_db)

    def resolve(self, url: str) -> Optional[List[str]]:
        """解析URL的域名为IP地址"""
        try:
            domain = urlparse(url).netloc
            if not domain:
                return None

            # 先查缓存
            cached_ips = self.cache.get(domain)
            if cached_ips:
                return cached_ips

            # 缓存未命中，进行DNS解析
            answers = self.resolver.resolve(domain, 'A')
            ips = [str(rdata) for rdata in answers]
            
            # 更新缓存
            self.cache.set(domain, ips)
            
            return ips
        except Exception as e:
            print(f"DNS resolution error for {url}: {str(e)}")
            return None

    def resolve_bulk(self, urls: List[str]) -> Dict[str, List[str]]:
        """批量解析URLs"""
        results = {}
        for url in urls:
            ips = self.resolve(url)
            if ips:
                results[url] = ips
        return results

    def clear_cache(self, domain: Optional[str] = None):
        """清除DNS缓存
        
        Args:
            domain: 如果指定，只清除该域名的缓存；否则清除所有缓存
        """
        if domain:
            self.cache.redis_client.delete(self.cache._get_cache_key(domain))
        else:
            for key in self.cache.redis_client.scan_iter(f"{self.cache.cache_key_prefix}*"):
                self.cache.redis_client.delete(key)
