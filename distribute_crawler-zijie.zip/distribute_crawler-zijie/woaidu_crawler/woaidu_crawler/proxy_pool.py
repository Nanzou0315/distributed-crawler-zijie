#!/usr/bin/env python
# -*- coding: utf-8 -*-

import aiohttp
import asyncio
import random
import time
import redis
import json
from typing import List, Dict, Optional
from datetime import datetime

class ProxyPool:
    def __init__(self, redis_host: str = 'localhost', redis_port: int = 6379, redis_db: int = 0):
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, db=redis_db)
        self.proxy_key = 'proxy_pool'
        self.proxy_score_key = 'proxy_scores'
        self.min_score = 0
        self.max_score = 100
        self.initial_score = 50

    async def check_proxy(self, proxy: str) -> bool:
        """检查代理是否可用"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get('http://www.baidu.com', 
                                    proxy=f"http://{proxy}", 
                                    timeout=5) as response:
                    return response.status == 200
        except:
            return False

    def add_proxy(self, proxy: str):
        """添加新代理到池中"""
        if not self.redis_client.zscore(self.proxy_score_key, proxy):
            self.redis_client.zadd(self.proxy_score_key, {proxy: self.initial_score})
            proxy_info = {
                'address': proxy,
                'last_used': 0,
                'success_count': 0,
                'fail_count': 0,
                'added_time': datetime.now().timestamp()
            }
            self.redis_client.hset(self.proxy_key, proxy, json.dumps(proxy_info))

    def remove_proxy(self, proxy: str):
        """从池中移除代理"""
        self.redis_client.zrem(self.proxy_score_key, proxy)
        self.redis_client.hdel(self.proxy_key, proxy)

    def get_proxy(self) -> Optional[str]:
        """获取一个代理"""
        # 按分数从高到低获取代理
        proxies = self.redis_client.zrevrange(self.proxy_score_key, 0, 20)
        if not proxies:
            return None
        
        # 随机选择一个代理
        proxy = random.choice(proxies).decode()
        
        # 更新代理使用时间
        proxy_info = json.loads(self.redis_client.hget(self.proxy_key, proxy))
        proxy_info['last_used'] = time.time()
        self.redis_client.hset(self.proxy_key, proxy, json.dumps(proxy_info))
        
        return proxy

    def update_score(self, proxy: str, success: bool):
        """更新代理分数"""
        current_score = self.redis_client.zscore(self.proxy_score_key, proxy) or self.initial_score
        
        # 获取代理信息
        proxy_info = json.loads(self.redis_client.hget(self.proxy_key, proxy))
        
        if success:
            # 成功时增加分数
            new_score = min(current_score + 1, self.max_score)
            proxy_info['success_count'] += 1
        else:
            # 失败时减少分数
            new_score = max(current_score - 2, self.min_score)
            proxy_info['fail_count'] += 1
        
        # 更新分数
        self.redis_client.zadd(self.proxy_score_key, {proxy: new_score})
        
        # 更新代理信息
        self.redis_client.hset(self.proxy_key, proxy, json.dumps(proxy_info))
        
        # 如果分数太低，移除代理
        if new_score <= self.min_score:
            self.remove_proxy(proxy)

    async def refresh_pool(self):
        """刷新代理池"""
        # 这里可以添加从各种代理源获取新代理的逻辑
        proxy_sources = [
            'https://www.kuaidaili.com/free/',
            'http://www.ip3366.net/free/',
            # 添加更多代理源
        ]
        
        async with aiohttp.ClientSession() as session:
            for source in proxy_sources:
                try:
                    async with session.get(source) as response:
                        if response.status == 200:
                            # 解析页面获取代理
                            # 这里需要根据不同代理源的页面结构来实现解析逻辑
                            pass
                except:
                    continue

    def get_pool_stats(self) -> Dict:
        """获取代理池统计信息"""
        total_proxies = self.redis_client.zcard(self.proxy_score_key)
        all_proxies = self.redis_client.hgetall(self.proxy_key)
        
        total_success = 0
        total_fail = 0
        for proxy_info in all_proxies.values():
            info = json.loads(proxy_info)
            total_success += info['success_count']
            total_fail += info['fail_count']
        
        return {
            'total_proxies': total_proxies,
            'total_success': total_success,
            'total_fail': total_fail,
            'success_rate': total_success / (total_success + total_fail) if (total_success + total_fail) > 0 else 0
        }

    def clean_pool(self):
        """清理代理池中的无效代理"""
        all_proxies = self.redis_client.zrange(self.proxy_score_key, 0, -1)
        for proxy in all_proxies:
            proxy = proxy.decode()
            proxy_info = json.loads(self.redis_client.hget(self.proxy_key, proxy))
            
            # 移除长时间未使用的代理
            if time.time() - proxy_info['last_used'] > 86400:  # 24小时
                self.remove_proxy(proxy)
            
            # 移除成功率过低的代理
            total_requests = proxy_info['success_count'] + proxy_info['fail_count']
            if total_requests > 100 and proxy_info['success_count'] / total_requests < 0.3:
                self.remove_proxy(proxy)
