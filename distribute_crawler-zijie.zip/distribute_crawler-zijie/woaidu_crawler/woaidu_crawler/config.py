#!/usr/bin/env python
# -*- coding: utf-8 -*-

# Redis配置
REDIS_HOST = 'localhost'
REDIS_PORT = 6379
REDIS_DB = 0

# MongoDB配置
MONGODB_URI = 'mongodb://localhost:27017/'
MONGODB_DB = 'woaidu_crawler'

# URL分发策略
URL_DISPATCH_STRATEGIES = {
    'round_robin': 'woaidu_crawler.url_dispatch.RoundRobinStrategy',
    'domain_hash': 'woaidu_crawler.url_dispatch.DomainHashStrategy'
}

# 爬虫配置
CRAWLER_CONFIG = {
    'CONCURRENT_REQUESTS': 32,  # 全局最大并发请求数
    'CONCURRENT_REQUESTS_PER_DOMAIN': 8,  # 每个域名的最大并发请求数
    'DOWNLOAD_DELAY': 1,  # 下载延迟，秒
    'ROBOTSTXT_OBEY': True,  # 遵守robots.txt规则
}

# 代理配置
PROXY_POOL_SIZE = 100  # 代理池大小
PROXY_REFRESH_INTERVAL = 3600  # 代理刷新间隔，秒

# DNS缓存配置
DNS_CACHE_SIZE = 10000
DNS_CACHE_EXPIRE = 3600  # DNS缓存过期时间，秒

# 数据处理配置
CHUNK_SIZE = 1000  # 数据处理批次大小
MAX_RETRIES = 3  # 最大重试次数
