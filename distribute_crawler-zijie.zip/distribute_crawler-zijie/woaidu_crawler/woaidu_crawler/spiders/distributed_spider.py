#!/usr/bin/env python
# -*- coding: utf-8 -*-

import uuid
import time
from typing import Optional, Generator, Dict
from urllib.parse import urlparse
import scrapy
from scrapy import Request, Spider
from scrapy.http import Response
from scrapy.exceptions import NotConfigured

from woaidu_crawler.url_dispatch import URLDispatcher
from woaidu_crawler.dns_resolver import DNSResolver
from woaidu_crawler.proxy_pool import ProxyPool
from woaidu_crawler.crawler_monitor import CrawlerMonitor
from woaidu_crawler.items import WoaiduCrawlerItem

class DistributedSpider(Spider):
    name = 'distributed_spider'
    
    custom_settings = {
        'CONCURRENT_REQUESTS': 32,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 8,
        'DOWNLOAD_DELAY': 1,
        'ROBOTSTXT_OBEY': True,
        'COOKIES_ENABLED': False,
        'USER_AGENT': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        
        # 生成唯一的worker ID
        self.worker_id = str(uuid.uuid4())
        
        # 初始化组件
        self.url_dispatcher = URLDispatcher('domain_hash')
        self.dns_resolver = DNSResolver()
        self.proxy_pool = ProxyPool()
        self.monitor = CrawlerMonitor()
        
        # 注册worker
        self.register_worker()
        
        # 初始化统计信息
        self.stats = {
            'requests': 0,
            'responses': 0,
            'items': 0,
            'errors': 0
        }
        
        # 启动心跳
        self.start_heartbeat()

    def register_worker(self):
        """注册worker"""
        info = {
            'name': self.name,
            'settings': self.custom_settings,
            'host': 'localhost'  # 在实际部署时应该是真实的主机名
        }
        self.monitor.register_worker(self.worker_id, info)
        self.url_dispatcher.register_worker(self.worker_id)

    def start_heartbeat(self):
        """启动心跳"""
        def update_heartbeat():
            while True:
                self.monitor.update_worker_heartbeat(self.worker_id)
                self.monitor.update_worker_stats(self.worker_id, self.stats)
                time.sleep(10)
        
        from threading import Thread
        heartbeat_thread = Thread(target=update_heartbeat, daemon=True)
        heartbeat_thread.start()

    def start_requests(self) -> Generator[Request, None, None]:
        """开始请求"""
        # 从Redis获取分配给该worker的URLs
        urls = self.get_assigned_urls()
        for url in urls:
            yield self.make_request_with_proxy(url)

    def get_assigned_urls(self) -> list:
        """获取分配给该worker的URLs"""
        redis_key = f'worker:{self.worker_id}:urls'
        urls = []
        while True:
            url = self.url_dispatcher.redis_client.lpop(redis_key)
            if not url:
                break
            urls.append(url.decode())
        return urls

    def make_request_with_proxy(self, url: str) -> Request:
        """使用代理创建请求"""
        # 解析域名
        ips = self.dns_resolver.resolve(url)
        if not ips:
            self.logger.error(f"Failed to resolve DNS for {url}")
            return None

        # 获取代理
        proxy = self.proxy_pool.get_proxy()
        
        # 更新统计信息
        self.stats['requests'] += 1
        
        return Request(
            url=url,
            callback=self.parse,
            errback=self.handle_error,
            meta={
                'proxy': f'http://{proxy}' if proxy else None,
                'original_url': url,
                'dns_resolved': ips[0]
            },
            dont_filter=True
        )

    def parse(self, response: Response) -> Generator[Request, None, None]:
        """解析响应"""
        # 更新统计信息
        self.stats['responses'] += 1
        
        # 更新代理状态
        if 'proxy' in response.meta:
            proxy = response.meta['proxy'].replace('http://', '')
            self.proxy_pool.update_score(proxy, True)
        
        # 解析页面内容
        try:
            # 提取新的URLs
            new_urls = response.css('a::attr(href)').getall()
            for url in new_urls:
                if url:
                    url = response.urljoin(url)
                    # 将新URL提交给URL分发器
                    worker_id = self.url_dispatcher.dispatch_url(url)
                    if worker_id == self.worker_id:
                        yield self.make_request_with_proxy(url)
            
            # 提取页面数据
            item = self.extract_data(response)
            if item:
                self.stats['items'] += 1
                yield item
                
        except Exception as e:
            self.logger.error(f"Error parsing {response.url}: {str(e)}")
            self.stats['errors'] += 1

    def extract_data(self, response: Response) -> Optional[Dict]:
        """提取页面数据"""
        try:
            item = WoaiduCrawlerItem()
            # 使用选择器提取数据
            item['book_name'] = response.css('div.zizida::text').get()
            item['author'] = response.css('div.xiaoxiao::text').get()
            item['book_description'] = response.css('div.lili::text').get()
            item['book_covor_image_url'] = response.css('div.hong img::attr(src)').get()
            item['original_url'] = response.url
            
            # 提取下载信息
            download_info = []
            for dl_div in response.css('div.xiazai_xiao'):
                info = {
                    'url': dl_div.css('a::attr(href)').get(),
                    'source': dl_div.css('a::text').get()
                }
                download_info.append(info)
            item['book_download'] = download_info
            
            return item
        except Exception as e:
            self.logger.error(f"Error extracting data from {response.url}: {str(e)}")
            return None

    def handle_error(self, failure):
        """处理请求错误"""
        # 更新统计信息
        self.stats['errors'] += 1
        
        # 更新代理状态
        request = failure.request
        if 'proxy' in request.meta:
            proxy = request.meta['proxy'].replace('http://', '')
            self.proxy_pool.update_score(proxy, False)
        
        # 重试请求
        return self.make_request_with_proxy(request.meta['original_url'])

    def closed(self, reason):
        """爬虫关闭时的清理工作"""
        self.url_dispatcher.unregister_worker(self.worker_id)
