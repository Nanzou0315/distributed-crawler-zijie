#!/usr/bin/env python
# -*- coding: utf-8 -*-

import redis
import json
import time
from typing import Dict, List
from datetime import datetime

class CrawlerMonitor:
    def __init__(self, redis_host: str = 'localhost', redis_port: int = 6379, redis_db: int = 0):
        self.redis_client = redis.Redis(host=redis_host, port=redis_port, db=redis_db)
        self.stats_key = 'crawler_stats'
        self.worker_key = 'crawler_workers'
        self.heartbeat_timeout = 30  # 心跳超时时间（秒）

    def register_worker(self, worker_id: str, info: Dict):
        """注册爬虫worker"""
        worker_info = {
            'id': worker_id,
            'start_time': datetime.now().timestamp(),
            'last_heartbeat': datetime.now().timestamp(),
            'status': 'running',
            **info
        }
        self.redis_client.hset(self.worker_key, worker_id, json.dumps(worker_info))

    def update_worker_heartbeat(self, worker_id: str):
        """更新worker心跳"""
        worker_info = self.redis_client.hget(self.worker_key, worker_id)
        if worker_info:
            info = json.loads(worker_info)
            info['last_heartbeat'] = datetime.now().timestamp()
            self.redis_client.hset(self.worker_key, worker_id, json.dumps(info))

    def update_worker_stats(self, worker_id: str, stats: Dict):
        """更新worker统计信息"""
        current_stats = self.redis_client.hget(self.stats_key, worker_id)
        if current_stats:
            current_stats = json.loads(current_stats)
            # 合并统计信息
            for key, value in stats.items():
                if key in current_stats:
                    current_stats[key] += value
                else:
                    current_stats[key] = value
        else:
            current_stats = stats
        
        self.redis_client.hset(self.stats_key, worker_id, json.dumps(current_stats))

    def get_worker_stats(self, worker_id: str = None) -> Dict:
        """获取worker统计信息"""
        if worker_id:
            stats = self.redis_client.hget(self.stats_key, worker_id)
            return json.loads(stats) if stats else {}
        else:
            all_stats = self.redis_client.hgetall(self.stats_key)
            return {k.decode(): json.loads(v) for k, v in all_stats.items()}

    def get_active_workers(self) -> List[Dict]:
        """获取所有活跃的workers"""
        current_time = datetime.now().timestamp()
        workers = []
        
        all_workers = self.redis_client.hgetall(self.worker_key)
        for worker_id, worker_info in all_workers.items():
            info = json.loads(worker_info)
            # 检查心跳是否超时
            if current_time - info['last_heartbeat'] <= self.heartbeat_timeout:
                workers.append(info)
            else:
                # 更新worker状态为离线
                info['status'] = 'offline'
                self.redis_client.hset(self.worker_key, worker_id, json.dumps(info))
        
        return workers

    def get_system_stats(self) -> Dict:
        """获取系统整体统计信息"""
        all_stats = self.get_worker_stats()
        system_stats = {
            'total_requests': 0,
            'total_responses': 0,
            'total_items': 0,
            'total_errors': 0,
            'active_workers': len(self.get_active_workers()),
            'start_time': min([w['start_time'] for w in self.get_active_workers()]) if self.get_active_workers() else 0
        }
        
        for worker_stats in all_stats.values():
            system_stats['total_requests'] += worker_stats.get('requests', 0)
            system_stats['total_responses'] += worker_stats.get('responses', 0)
            system_stats['total_items'] += worker_stats.get('items', 0)
            system_stats['total_errors'] += worker_stats.get('errors', 0)
        
        return system_stats

    def clean_inactive_workers(self):
        """清理不活跃的workers"""
        current_time = datetime.now().timestamp()
        all_workers = self.redis_client.hgetall(self.worker_key)
        
        for worker_id, worker_info in all_workers.items():
            info = json.loads(worker_info)
            if current_time - info['last_heartbeat'] > self.heartbeat_timeout * 2:
                # 删除超时worker的信息和统计数据
                self.redis_client.hdel(self.worker_key, worker_id)
                self.redis_client.hdel(self.stats_key, worker_id)
