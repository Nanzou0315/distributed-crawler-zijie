#!/usr/bin/env python
# -*- coding: utf-8 -*-

import hashlib
from abc import ABC, abstractmethod
from typing import List, Optional
import redis
from urllib.parse import urlparse

class BaseURLDispatchStrategy(ABC):
    @abstractmethod
    def dispatch(self, url: str, worker_ids: List[str]) -> str:
        """分发URL到指定的worker"""
        pass

class RoundRobinStrategy(BaseURLDispatchStrategy):
    def __init__(self):
        self.current = 0
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)

    def dispatch(self, url: str, worker_ids: List[str]) -> str:
        if not worker_ids:
            return None
        
        # 使用Redis的原子操作来实现分布式的Round Robin
        worker_index = self.redis_client.incr('url_dispatch_counter') % len(worker_ids)
        return worker_ids[worker_index]

class DomainHashStrategy(BaseURLDispatchStrategy):
    def dispatch(self, url: str, worker_ids: List[str]) -> str:
        if not worker_ids:
            return None
        
        # 基于域名的哈希分发，相同域名的URL会被分发到同一个worker
        domain = urlparse(url).netloc
        hash_value = int(hashlib.md5(domain.encode()).hexdigest(), 16)
        return worker_ids[hash_value % len(worker_ids)]

class URLDispatcher:
    def __init__(self, strategy: str = 'round_robin'):
        self.strategies = {
            'round_robin': RoundRobinStrategy(),
            'domain_hash': DomainHashStrategy()
        }
        self.strategy = self.strategies.get(strategy)
        if not self.strategy:
            raise ValueError(f"Unknown strategy: {strategy}")
        
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)

    def register_worker(self, worker_id: str):
        """注册一个新的worker"""
        self.redis_client.sadd('workers', worker_id)

    def unregister_worker(self, worker_id: str):
        """注销一个worker"""
        self.redis_client.srem('workers', worker_id)

    def get_workers(self) -> List[str]:
        """获取所有活跃的workers"""
        return [w.decode() for w in self.redis_client.smembers('workers')]

    def dispatch_url(self, url: str) -> Optional[str]:
        """分发URL到指定的worker"""
        workers = self.get_workers()
        if not workers:
            return None
        return self.strategy.dispatch(url, workers)

    def assign_urls(self, urls: List[str]):
        """批量分发URLs"""
        assignments = {}
        for url in urls:
            worker_id = self.dispatch_url(url)
            if worker_id:
                if worker_id not in assignments:
                    assignments[worker_id] = []
                assignments[worker_id].append(url)
        
        # 将分配结果存储到Redis
        for worker_id, worker_urls in assignments.items():
            self.redis_client.rpush(f'worker:{worker_id}:urls', *worker_urls)
